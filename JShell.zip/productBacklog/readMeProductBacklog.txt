1) You will create a single file called productBacklogFor2A.txt in here. 

2) You can follow the lecture slides on Scrum Software Development Process on how to create user stories for this.  

3) The product backlog essentially will contain all the usecases/user stories, functional requirements of your project. These are the entities that the customer expects at the due date of your assignment. 

4) This is the very first thing that you will do before starting any work on Assignment2.

5) The product backlog will contain 'n' rows where 'n' is the number of user stories. The two columns are: 
   Column1 = User Stories 
   Column2 = Time estimate (in hrs or days) that is required to complete the user story. 
