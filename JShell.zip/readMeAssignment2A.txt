--Each folder has a specific readMe.txt for you to get started. Make sure to read them carefully. 

--Product Backlog is the very first thing that you will start work on for Assignment2A.
--You have exactly two days to work on your product backlog i.e. 16th and 17th October. Sprint 1 begins on 18th October @ 12:01am

--src will contain all your source code. It will contain all your .java files.

----You are welcome to create any subpackages within the src folder to organize your .java files. 
----BUT JSHELL.JAVA MUST ALWAYS RESIDE IN THE PACKAGE 'DRIVER'. YOU CANNOT CHANGE THE LOCATION OF JSHELL.JAVA IN YOUR SUBVERSION REPOSITORY.
--  JShell is the class that contains the main function and drives your entire assignment. 
----All your unit tests will reside in the package 'test'. You cannot change the location of your test package in your subversion repository.  

--tests will contain all your JUnit test cases (.java files). Your lab sometime end of October will be your first introduction on how to write JUnit tests. 

--You are welcome to dedicate the last sprint (see readMe inside the Sprint folder) for testing if your team so desires. Depending on how much we complete unit testing in 
lecture (will make an announcement if testing were to get dropped from assignment 2A), however, testing is much more of a bigger deal starting assignment 2B.   
