Each one of you is responsible for adding a file in this folder every three days with the following contents: Do not ask your colleague to commit for you. That won't count. 

a) What did I work on in the last three days? 

b) What do I plan to work in the next three days?

c) Am I blocked on anything?  


Example1: 

What did I work on in the last three days?
    - worked on JShell and FileOperation
    - brainstormed design ideas with team for echo and mkdir commands. 

What do I plan to work in the next three days?
    - finish JShell and FileOperation
    - work on new tasks for sprint 2
        - start and finish Man, Echo, Mv

Am I blocked on anything?
    - Need FileSystem, StandardOutput, StandardError, and Command to be completed (or at least prototyped) before I can continue working

 
The filename for this will be: 
UTORIDUserNameSprint#Date.txt

for example:

c1abcxyzSprint1October20.txt

where c1abcxyz=UTORIDUserName
      1 in Sprint1=Sprint #

The days (between 10pm and 11:59pm on these days) when you commit your daily scrum meetings are as follows:
a)  20th October
b)  23rd October
c)  27th October
d)  30th October
e)  3rd  November
f)  7th  November
