--All your crc cards will reside in here.

--Your code structure MUST always reflect the design outlined in CRC Cards.  

--If at any point you change or modify your design: 
----a) Change your CRC Cards to reflect the new design. 
----b) Change your code sturcture so that it reflects the new design.  

--Follow the same format as in Assignment1 for crc cards.
